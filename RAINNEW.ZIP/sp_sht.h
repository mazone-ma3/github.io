/* Game Data (Common) for MSX2 */
#ifndef SP_SHT_H_INCLUDE
#define SP_SHT_H_INCLUDE

/*#include "sp_loop.h"*/

enum {
	IMG_SIZE_X = 16,

	/* �X�v���C�g�\���͈� */
	SPR_MAX_X = ((SCREEN_MAX_X - SPR_OFS_X) << SHIFT_NUM),
	SPR_MAX_Y = ((SCREEN_MAX_Y - SPR_OFS_Y) << SHIFT_NUM_Y),

	SPR_MIN_X = (-SPR_OFS_X << SHIFT_NUM),
	SPR_MIN_Y = (-SPR_OFS_Y << SHIFT_NUM_Y),
//	SPR_MIN_X = (-16 << SHIFT_NUM),
//	SPR_MIN_Y = (-16 << SHIFT_NUM_Y),

	SPR_OUT_X = 256,
	SPR_OUT_Y = 212,

	SPR_IN_X = -16,
	SPR_IN_Y = -16,

	SPR_DEL_X =((SPR_OUT_X - SPR_OFS_X) << SHIFT_NUM),
	SPR_DEL_Y =((SPR_OUT_Y - SPR_OFS_Y) << SHIFT_NUM_Y),

	/* ���@�X�v���C�g��� */
	JIKI_PARTS_X = 1,	/* �g�ݍ��킹�p�[�c�� */
	JIKI_PARTS_Y = 1,
	JIKI_PARTS = 2, //JIKI_PARTS_X * JIKI_PARTS_Y,

	JIKI_INIT_X = ((2 * 8     - SPR_OFS_X) << SHIFT_NUM),	/* �����\���ʒu */
	JIKI_INIT_Y = ((7 * 8 + 4 - SPR_OFS_Y) << SHIFT_NUM_Y),

	JIKI_MAX_X = ((SCREEN_MAX_X) << SHIFT_NUM),	/* ���@�ړ��͈� */
	JIKI_MAX_Y = ((18 * 8 - SPR_OFS_Y - 16) << SHIFT_NUM_Y),

	JIKI_MIN_X = (SPR_MIN_X),
	JIKI_MIN_Y = (SPR_MIN_Y),

	/* �����蔻���� �I�t�Z�b�g�ƃT�C�Y */
	MY_OFS_X = 9,
	MY_OFS_Y = 9,

	MY_SIZE_X = 1,
	MY_SIZE_Y = 1,


	TK_OFS_X = 0,
	TK_OFS_Y = 0,

	TK_SIZE_X = 16,
	TK_SIZE_Y = 16,


	TKD_OFS_X = 2,
	TKD_OFS_Y = 2,

	TKD_SIZE_X = 4,
	TKD_SIZE_Y = 4,

	/* �\�������� */
	MAX_MYSHOT = 1, //12, //8, //6,
	MAX_TEKI = 5, //8,

	/* �\���擪�v���[��No. �Œ� */
	MYSHOT_OFFSET = JIKI_PARTS,
	TEKI_OFFSET = MYSHOT_OFFSET + MAX_MYSHOT,
	TKSHOT_OFFSET = TEKI_OFFSET + MAX_TEKI * 2, // * 2,

	/* �G�e�\�������� */
	MAX_TKSHOT = 5 //8 //4 //MAX_SPRITE - TKSHOT_OFFSET

};

/* �����蔻��Z�o�}�N�� */

#define CLGN(head_x, head_y, size_x, size_y) {\
	((head_x - MY_OFS_X + size_x   ) << SHIFT_NUM),\
	((head_x - MY_OFS_X - MY_SIZE_X) << SHIFT_NUM),\
	((head_y - MY_OFS_Y + size_y   ) << SHIFT_NUM_Y),\
	((head_y - MY_OFS_Y - MY_SIZE_Y) << SHIFT_NUM_Y),\
}

typedef struct {
	int x1;
	int x2;
	int y1;
	int y2;
} COLIGION;

COLIGION hantei[2] = {
	CLGN(TK_OFS_X, TK_OFS_Y, TK_SIZE_X, TK_SIZE_Y),
	CLGN(TK_OFS_X, TK_OFS_Y, TK_SIZE_X, TK_SIZE_Y),
};


#include "spr_def.h"

enum{
	SINFREQ = 19 * 2,
	SINRATE = 4
};

int sinwave[SINFREQ] = {
	0,  1,  2,  3,  3,  4,  4,  4,  5,  5,  5,  5,  4,  4,  4,  3,  3,  2,  1,
	0, -1, -2, -3, -3, -4, -4, -4, -5, -5, -5, -5, -4, -4, -4, -3, -3, -2, -1,
};

int direction[33][2] = {
	{ 12,  0},	/* �E = 0 */
	{ 11,  2},
	{ 10,  4},
	{  9,  6},
	{  8,  8},
	{  6,  9},
	{  4, 10},
	{  2, 11},

	{  0, 12},	/* �� = 8 */
	{ -2, 11},
	{ -4, 10},
	{ -6,  9},
	{ -8,  8},
	{ -9,  6},
	{-10,  4},
	{-11,  2},

	{-12, -0},	/* �� = 16 */
	{-11, -2},
	{-10, -4},
	{ -9, -6},
	{ -8, -8},
	{ -6, -9},
	{ -4,-10},
	{ -2,-11},

	{  0,-12},	/* �� = 24 */
	{  2,-11},
	{  4,-10},
	{  6, -9},
	{  8, -8},
	{  9, -6},
	{ 10, -4},
	{ 11, -2},

	{ 0, 0},
};

enum {
	DIR_RIGHT = 0,	/* �c�ł͏� */
	DIR_DOWN  = 8,	/* �c�ł͉E */
	DIR_LEFT = 16,	/* �c�ł͉� */
	DIR_UP   = 24,	/* �c�ł͍� */
	DIR_OFF = 32	/* �c�ł͖� */
};

#endif

