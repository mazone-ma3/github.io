/* �g�ݍ��킹�X�v���C�g��`  */

#ifndef SPR_DEF_H_INCLUDE
#define SPR_DEF_H_INCLUDE

#define CONST
// const

/* �����X�v���C�g��`�⏕�}�N�� */
//#define IMG_SET(X, Y) (CHR_TOP + X + IMG_SIZE_X * Y)

#define IMG_SET(X, Y) 0

#define SPR_FLIP_H 1
#define SPR_FLIP_V 2

/* 1�~1 �X�v���C�g ��`�ȗ����}�N�� */
#define MK_SPR1(VAR, NO) CONST SPR_COMB VAR[] = {\
	{ NO,  0,  0 ,0,},\
};

/* ���E���] */
#define MK_SPR1_RL(VAR, NO) CONST SPR_COMB VAR[] = {\
	{ IMG_SET(NO    , 0) | SPR_FLIP_H,  0,  8, 0,},\
};

/* �㉺���] */
#define MK_SPR1_UD(VAR, NO) CONST SPR_COMB VAR[] = {\
	{ IMG_SET(NO    , 0) | SPR_FLIP_V,  8,  0, 0,},\
};

/* ���� */
#define MK_SPR1_RV(VAR, NO) CONST SPR_COMB VAR[] = {\
	{ IMG_SET(NO    , 0) | SPR_FLIP_H | SPR_FLIP_V,  8,  8, 0,},\
};



/* ���@��` */

CONST SPR_COMB jikij_comb[JIKI_PARTS] = {
	{  6*4,  0,  0,0,},
	{  7*4,  0,  0,0,},
//	{  IMG_SET(1, 7),  16, 0,0,},
};

CONST SPR_COMB jikil_comb[JIKI_PARTS] = {
	{  2*4,  0,  0,0,},
	{  3*4,  0,  0,0,},
//	{  IMG_SET(1, 7),  16, 0,0,},
};


CONST SPR_COMB jikir_comb[JIKI_PARTS] = {
	{  4*4,  0,  0,0,},
	{  5*4,  0,  0,0,},
//	{  IMG_SET(3, 7),  16, 0,0,},
};

CONST SPR_COMB jikic_comb[JIKI_PARTS] = {
	{  0*4,  0,  0,0,},
	{  1*4,  0,  0,0,},
//	{  IMG_SET(5, 7),  16, 0,0,},
};

/* ���@�V���b�g��` */

CONST SPR_COMB myshot1_comb[] = {
	{  8*4,  0,  4,0,},
//	{  9*4,  0,  4,0,},
//	{  IMG_SET(0, 6),  0,  8,0,},
/*	{  IMG_SET(3, 1), 13,  8,0,} */
};

CONST SPR_COMB myshot2_comb[] = {
	{  10*4,  0,  4,0,},
//	{  11*4,  0,  4,0,},
//	{  IMG_SET(3, 0),  1,  8,0,},
};

CONST SPR_COMB myshot3_comb[] = {
	{  6*4,  0,  4,0,},
//	{  8,  0,  0,0,},
//	{  IMG_SET(3, 0)  | SPR_FLIP_V,  1,  8,0,},
};

/* �G�V���b�g��` */

CONST SPR_COMB tkshot1_comb[] = {
	{  8*4,  0,  0,0,},
//	{  IMG_SET(1, 6), 0, 0,0,},
};

CONST SPR_COMB tkshot2_comb[1] = {
	{  8*4,  0,  0,0,},
////	{  10*4,  -4,  0,0,},
//	{  11*4,  -4,  0,0,},
//	{  IMG_SET(2, 6), -4, 0,0,},
};

CONST SPR_COMB tkshot3_comb[1] = {
	{  10*4,  0,  0,0,},
};

/* �G���G��` */

//MK_SPR1(teki1_0comb, 12*4)) //IMG_SET(0, 4))
CONST SPR_COMB teki1_0comb[2] = {
	{  0*4,  0,  0,0,},
	{  1*4,  0,  0,0,},
};

MK_SPR1(teki1_1comb, IMG_SET(1, 4))

//MK_SPR1(teki3_comb, IMG_SET(2, 4))
CONST SPR_COMB teki3_comb[2] = {
	{  0*4,  0,  0,0,},
	{  1*4,  0,  0,0,},
};
//MK_SPR1(teki4_comb, IMG_SET(3, 4))
CONST SPR_COMB teki4_comb[2] = {
	{  0*4,  0,  0,0,},
	{  1*4,  0,  0,0,},
};

/*
MK_SPR1(teki5_0comb, IMG_SET(0, 5))
MK_SPR1(teki5_1comb, IMG_SET(1, 5))
MK_SPR1(teki5_2comb, IMG_SET(2, 5))
MK_SPR1(teki5_3comb, IMG_SET(3, 5))
MK_SPR1(teki5_4comb, IMG_SET(4, 5))

MK_SPR1_RL(teki5_5comb, IMG_SET(4, 5))
MK_SPR1_RL(teki5_6comb, IMG_SET(3, 5))
MK_SPR1_RL(teki5_7comb, IMG_SET(2, 5))
MK_SPR1_RL(teki5_8comb, IMG_SET(1, 5))

MK_SPR1_RV(teki5_9comb, IMG_SET(1, 5))
MK_SPR1_RV(teki5_acomb, IMG_SET(2, 5))
MK_SPR1_RV(teki5_bcomb, IMG_SET(3, 5))
MK_SPR1_RV(teki5_ccomb, IMG_SET(4, 5))

MK_SPR1_UD(teki5_dcomb, IMG_SET(3, 5))
MK_SPR1_UD(teki5_ecomb, IMG_SET(2, 5))
MK_SPR1_UD(teki5_fcomb, IMG_SET(1, 5))
*/
/*MK_SPR1_RL(teki5_acomb, IMG_SET(4, 0)); */

/*
MK_SPR1(teki6_0comb, IMG_SET(0, 3))
MK_SPR1(teki6_1comb, IMG_SET(1, 3))
MK_SPR1(teki6_2comb, IMG_SET(2, 3))
*/
/*MK_SPR1(baku1_comb, IMG_SET(0, 0))
MK_SPR1(baku2_comb, IMG_SET(1, 0))
MK_SPR1(baku3_comb, IMG_SET(2, 0))
*/
CONST SPR_COMB baku1_comb[2] = {
	{  12*4,  0,  0,0,},
	{  13*4,  0,  0,0,},
};
CONST SPR_COMB baku2_comb[2] = {
	{  14*4,  0,  0,0,},
	{  15*4,  0,  0,0,},
};
CONST SPR_COMB baku3_comb[2] = {
	{  16*4,  0,  0,0,},
	{  17*4,  0,  0,0,},
};

/*#define WIDE_PARTS(X, Y, Z) \
	{  IMG_SET(X + Y, 0), -28, Z * 8, 0,},\
	{  IMG_SET(X + Y, 4),  4, Z * 8, 0,}*/
/*,\*/

#define ZAKO_PARTS 1
#define BOSS1_PARTS 2 //16 //4*2

CONST SPR_COMB boss1_comb[BOSS1_PARTS] = {
	{  0*4,  0,  0,0,},
	{  1*4,  0,  0,0,},
/*	{  24*4,  0 - 24,  0,0,},
	{  25*4,  0 - 24,  0,0,},
	{  26*4, 16 - 24,  0,0,},
	{  27*4, 16 - 24,  0,0,},
	{  28*4, 32 - 24,  0,0,},
	{  29*4, 32 - 24,  0,0,},
	{  30*4, 48 - 24,  0,0,},
	{  31*4, 48 - 24,  0,0,},
	{  32*4,  0 - 24, 16,0,},
	{  33*4,  0 - 24, 16,0,},
	{  34*4, 16 - 24, 16,0,},
	{  35*4, 16 - 24, 16,0,},
	{  36*4, 32 - 24, 16,0,},
	{  37*4, 32 - 24, 16,0,},
	{  38*4, 48 - 24, 16,0,},
	{  39*4, 48 - 24, 16,0,},
*/
/*	WIDE_PARTS(0, 1, -1),
	WIDE_PARTS(1, 1, 0),
	WIDE_PARTS(2, 1, 1),
	WIDE_PARTS(3, 1, 2),*/
};

CONST SPR_COMB boss1_comb_2[BOSS1_PARTS] = {
	{  0*4,  0,  0,0,},
	{  1*4,  0,  0,0,},
/*	{  38*4, 48 - 24, 16,0,},
	{  39*4, 48 - 24, 16,0,},
	{  26*4, 16 - 24,  0,0,},
	{  27*4, 16 - 24,  0,0,},
	{  28*4, 32 - 24,  0,0,},
	{  29*4, 32 - 24,  0,0,},
	{  30*4, 48 - 24,  0,0,},
	{  31*4, 48 - 24,  0,0,},
	{  32*4,  0 - 24, 16,0,},
	{  33*4,  0 - 24, 16,0,},
	{  34*4, 16 - 24, 16,0,},
	{  35*4, 16 - 24, 16,0,},
	{  36*4, 32 - 24, 16,0,},
	{  37*4, 32 - 24, 16,0,},
	{  24*4,  0 - 24,  0,0,},
	{  25*4,  0 - 24,  0,0,},*/
};

/*CONST SPR_COMB teki10_comb[] = {
	{  8,  0,  0,},
	{  9,  0,  8,},
	{ 24,  8,  0,},
	{ 25,  8,  8,},
};*/


/* �����X�v���C�g�ŏI��`�e�[�u�� */
/* �ł��E�A���S���Y��No. �Ȃ� */
CONST SPR_INFO spr_info[] = {
	{ JIKI_PARTS,    jikic_comb,},
	{ JIKI_PARTS,    jikir_comb,},
	{ JIKI_PARTS,    jikil_comb,},
	{ JIKI_PARTS,    jikij_comb,},

	{          1,  myshot1_comb,},
	{          1,  myshot2_comb,},
//	{          2,  myshot1_comb,},
//	{          1,  myshot2_comb,},
//	{          1,  myshot3_comb,},

	{          1,  tkshot1_comb,},
	{          1,  tkshot2_comb,},
	{          1,  tkshot3_comb,},

	{ 2,    baku1_comb,},
	{ 2,    baku2_comb,},
	{ 2,    baku3_comb,},

	{ ZAKO_PARTS,    teki1_1comb,},
	{ 2,    teki1_0comb,},
	{ 2,    teki3_comb,},
	{ 2,    teki4_comb,},
/*
	{ ZAKO_PARTS,    teki5_0comb,},
	{ ZAKO_PARTS,    teki5_1comb,},
	{ ZAKO_PARTS,    teki5_2comb,},
	{ ZAKO_PARTS,    teki5_3comb,},
	{ ZAKO_PARTS,    teki5_4comb,},
	{ ZAKO_PARTS,    teki5_5comb,},
	{ ZAKO_PARTS,    teki5_6comb,},
	{ ZAKO_PARTS,    teki5_7comb,},
	{ ZAKO_PARTS,    teki5_8comb,},
	{ ZAKO_PARTS,    teki5_9comb,},
	{ ZAKO_PARTS,    teki5_acomb,},
	{ ZAKO_PARTS,    teki5_bcomb,},
	{ ZAKO_PARTS,    teki5_ccomb,},
	{ ZAKO_PARTS,    teki5_dcomb,},
	{ ZAKO_PARTS,    teki5_ecomb,},
	{ ZAKO_PARTS,    teki5_fcomb,},

	{ ZAKO_PARTS,    teki6_0comb,},
	{ ZAKO_PARTS,    teki6_1comb,},
	{ ZAKO_PARTS,    teki6_2comb,},
*/
	{ BOSS1_PARTS,    boss1_comb,},
	{ BOSS1_PARTS,    boss1_comb_2,},
};

/* �����X�v���C�gNo.�Q�Ɨp�萔 */
enum {
	PAT_JIKI_C,
	PAT_JIKI_R,
	PAT_JIKI_L,
	PAT_JIKI_J,

	PAT_MYSHOT1,
	PAT_MYSHOT2,
};
//	PAT_MYSHOT3,

enum {
/*	PAT_BAKU1,
	PAT_BAKU2,
	PAT_BAKU3,
*/
	PAT_TEKI1,
	PAT_TEKI2,
	PAT_TEKI3,
	PAT_TEKI4,

	PAT_TKSHOT1,
	PAT_TKSHOT3,
};

enum {
	PAT_TKSHOT2 = PAT_TKSHOT1,
};

enum {
/*
	PAT_TEKI5_0,
	PAT_TEKI5_1,
	PAT_TEKI5_2,
	PAT_TEKI5_3,
	PAT_TEKI5_4,
	PAT_TEKI5_5,
	PAT_TEKI5_6,
	PAT_TEKI5_7,
	PAT_TEKI5_8,
	PAT_TEKI5_9,
	PAT_TEKI5_A,
	PAT_TEKI5_B,
	PAT_TEKI5_C,
	PAT_TEKI5_D,
	PAT_TEKI5_E,
	PAT_TEKI5_F,

	PAT_TEKI6_0,
	PAT_TEKI6_1,
	PAT_TEKI6_2,
*/
	PAT_BOSS1,
	PAT_BOSS1_2
};
/*
int teki5_pat[32] = {
	PAT_TEKI5_7,
	PAT_TEKI5_6,
	PAT_TEKI5_5,
	PAT_TEKI5_4,

	PAT_TEKI5_3,
	PAT_TEKI5_2,
	PAT_TEKI5_1,
	PAT_TEKI5_0,
	PAT_TEKI5_F,
	PAT_TEKI5_E,
	PAT_TEKI5_D,
	PAT_TEKI5_C,

	PAT_TEKI5_B,
	PAT_TEKI5_A,
	PAT_TEKI5_9,
	PAT_TEKI5_8,

};
*/
#define PAT_TEKIHEAD PAT_TEKI1

#endif
